const adminBtn = document.getElementById("adminBtn");
  const authBtn = document.getElementById("authBtn");
  const adminModal = document.getElementById("adminModal");
  const authModal = document.getElementById("authModal");
  const loginBtn = document.getElementById("loginBtn");
  const uploadSection = document.getElementById("uploadSection");
  const uploadBtn = document.getElementById("uploadBtn");
  const mainContent = document.getElementById("mainContent");
  const searchBar = document.getElementById("searchBar");
  const categoryNav = document.getElementById("categoryNav");
  
  // Auth Form Elements
  const authForm = document.getElementById("authForm");
  const signUpForm = document.getElementById("signUpForm");
  const authLoginBtn = document.getElementById("authLoginBtn");
  const authSignUpBtn = document.getElementById("authSignUpBtn");
  const authEmail = document.getElementById("authEmail");
  const authPass = document.getElementById("authPass");
  const signUpEmail = document.getElementById("signUpEmail");
  const signUpPass = document.getElementById("signUpPass");

  const ADMIN_PASSWORD = "KrAnThIkIrAn05240108";
  
  // User/App Data
  const defaultApps = [
    { name: "WhatsApp Messenger", image: "https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg", apk: "#", desc: "Fast, secure messaging and calling. Stay connected with friends and family across the globe with encrypted chats.", category: "Communication" },
    { name: "Instagram", image: "https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png", apk: "#", desc: "Share photos and reels with your community. Connect with friends and family through stories and direct messages.", category: "Communication" },
    { name: "PUBG Mobile", image: "https://upload.wikimedia.org/wikipedia/en/7/77/PUBG_Mobile_logo.png", apk: "#", desc: "An epic battle royale game with intense action. Drop in, scavenge, and fight to be the last one standing in 100-player battles.", category: "Games" },
    { name: "YouTube", image: "https://upload.wikimedia.org/wikipedia/commons/b/b8/YouTube_Logo_2017.svg", apk: "#", desc: "Watch and upload the world's videos. Enjoy music, news, and more from your favorite creators and channels.", category: "Multimedia" },
    { name: "Google Docs", image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Google_Docs_2020_icon.svg/1024px-Google_Docs_2020_icon.svg.png", apk: "#", desc: "Create and edit documents on the go. Collaborate in real-time with others.", category: "Productivity" },
    { name: "Spotify", image: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg", apk: "#", desc: "Music and podcasts for everyone. Stream millions of songs instantly.", category: "Multimedia" },
    { name: "Fitness Tracker", image: "https://via.placeholder.com/80/f44336/ffffff?text=FIT", apk: "#", desc: "Track your steps and monitor your health. Set goals and challenge friends.", category: "Lifestyle" },
  ];

  let apps = JSON.parse(localStorage.getItem("apps")) || defaultApps;
  let users = JSON.parse(localStorage.getItem("users")) || {};
  let currentUser = localStorage.getItem("currentUser") || null;
  // New variable to store the last rendered list
  let lastAppList = apps; 

  // --- Utility Functions ---

  function updateAuthButton() {
    if (currentUser) {
        authBtn.textContent = `Logout (${currentUser.split('@')[0]})`;
        authBtn.onclick = handleLogout;
    } else {
        authBtn.textContent = 'Sign Up / Login';
        authBtn.onclick = () => authModal.style.display = "flex";
    }
  }

  function showSignUp(e) {
      e.preventDefault();
      authForm.style.display = 'none';
      signUpForm.style.display = 'block';
  }

  function showLogin(e) {
      e.preventDefault();
      signUpForm.style.display = 'none';
      authForm.style.display = 'block';
  }

  // --- Authentication Handlers ---

  authSignUpBtn.onclick = () => {
    const email = signUpEmail.value.trim();
    const pass = signUpPass.value;

    if (!email || pass.length < 6) {
        alert("Please enter a valid email and a password of at least 6 characters.");
        return;
    }

    if (users[email]) {
        alert("This email is already registered. Please log in.");
        showLogin({preventDefault: () => {}});
        return;
    }

    users[email] = { password: pass };
    localStorage.setItem("users", JSON.stringify(users));
    alert("✅ Sign Up successful! Please log in.");
    signUpEmail.value = signUpPass.value = '';
    showLogin({preventDefault: () => {}});
  };

  authLoginBtn.onclick = () => {
    const email = authEmail.value.trim();
    const pass = authPass.value;
    const user = users[email];

    if (user && user.password === pass) {
        currentUser = email;
        localStorage.setItem("currentUser", currentUser);
        updateAuthButton();
        authModal.style.display = "none";
        alert(`👋 Welcome back, ${email.split('@')[0]}!`);
    } else {
        alert("❌ Invalid email or password.");
    }
  };

  function handleLogout() {
    currentUser = null;
    localStorage.removeItem("currentUser");
    updateAuthButton();
    alert("👋 You have been logged out.");
    // Reset view to login form
    authEmail.value = authPass.value = '';
    showLogin({preventDefault: () => {}});
  }


  // --- Admin Handlers ---

  adminBtn.onclick = () => adminModal.style.display = "flex";

  loginBtn.onclick = () => {
    const pass = document.getElementById("adminPassword").value;
    if (pass === ADMIN_PASSWORD) {
      uploadSection.style.display = "block";
      document.getElementById("adminPassword").value = "";
      alert("✅ Welcome Admin! Upload section unlocked.");
    } else {
      alert("❌ Incorrect password!");
    }
  };

  uploadBtn.onclick = () => {
    const name = document.getElementById("appName").value;
    const category = document.getElementById("appCategory").value;
    const image = document.getElementById("appImage").value;
    const apk = document.getElementById("appApk").value;
    const desc = document.getElementById("appDesc").value;

    if (!name || !image || !apk || !desc || !category) {
      alert("Please fill all fields!");
      return;
    }

    const app = { name, image, apk, desc, category };
    apps.unshift(app);
    localStorage.setItem("apps", JSON.stringify(apps));
    alert("✅ App Uploaded Successfully!");
    // Re-render the full list or the currently filtered view
    renderApps(lastAppList === apps ? apps : lastAppList); 
    // clear fields
    document.getElementById("appName").value = "";
    document.getElementById("appImage").value = "";
    document.getElementById("appApk").value = "";
    document.getElementById("appDesc").value = "";
  };

  // --- App Rendering & Filtering Functions ---

  function filterApps() {
    const query = searchBar.value.toLowerCase();
    const filteredApps = apps.filter(app => 
      app.name.toLowerCase().includes(query) || 
      app.desc.toLowerCase().includes(query)
    );
    // Clear active category when searching
    document.querySelectorAll('.cat-btn').forEach(btn => btn.classList.remove('active'));
    renderApps(filteredApps);
  }
  
  categoryNav.addEventListener('click', (e) => {
    if (e.target.classList.contains('cat-btn')) {
        const category = e.target.dataset.category;
        
        // Update active class
        document.querySelectorAll('.cat-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        
        // Filter and render
        searchBar.value = ''; // Clear search when filtering by category
        const filteredApps = (category === 'All') 
            ? apps 
            : apps.filter(app => app.category === category);
            
        renderApps(filteredApps);
    }
  });

  function renderApps(appList) {
    mainContent.className = "app-list";
    mainContent.innerHTML = "";
    const listToRender = appList || apps;
    lastAppList = listToRender; // Store the current list
    
    if (listToRender.length === 0) {
        mainContent.innerHTML = "<p style='text-align:center; padding: 50px;'>No apps found matching your criteria.</p>";
        return;
    }

    listToRender.forEach((a) => {
      const card = document.createElement("div");
      card.className = "app-card";
      card.innerHTML = `
        <img src="${a.image}" alt="${a.name} icon" onerror="this.onerror=null;this.src='https://via.placeholder.com/80/cccccc/333333?text=App'">
        <h3>${a.name}</h3>
        <p style="font-size: 0.85rem; color: var(--primary-color);">Category: ${a.category}</p>
        <p>${a.desc.slice(0, 50)}...</p>
      `;
      card.onclick = () => renderInstallPage(a);
      mainContent.appendChild(card);
    });
  }

  function renderInstallPage(app) {
    // Only allow install if logged in
    const installButtonHTML = currentUser 
        ? `<a href='${app.apk}' target='_blank'><button>📥 Install APK</button></a>`
        : `<button onclick="alert('Please log in to install apps!')">🔒 Log in to Install</button>`;

    mainContent.className = "app-detail-container";
    mainContent.innerHTML = `
      <div class='install-page'>
        <img src='${app.image}' alt='${app.name} icon' onerror="this.onerror=null;this.src='https://via.placeholder.com/120/cccccc/333333?text=App'">
        <h2>${app.name}</h2>
        <p style="color: ${app.category === 'Games' ? '#f44336' : '#34A853'}; font-weight: 600;">Category: ${app.category}</p>
        <p style="text-align: left; margin: 20px 0;"><strong>Description:</strong><br>${app.desc}</p>
        <div class="ads-banner"></div> 
        ${installButtonHTML}
        <button id="backToListBtn" onclick="renderApps(lastAppList)">← Back to List</button> 
      </div>
    `;
  }

  // Initial calls
  updateAuthButton();
  renderApps();